#include <stdio.h>
#include "run_test.h"

int main(void){

  run_test(1, charge(1100,1,0), 1100);

  return 0;
}
